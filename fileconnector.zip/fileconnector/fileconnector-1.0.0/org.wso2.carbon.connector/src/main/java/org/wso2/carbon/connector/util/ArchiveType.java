package org.wso2.carbon.connector.util;

public enum ArchiveType {
	TAR_GZIP, ZIP

}
